import React from "react";
import {
  Route,
  Routes,
  BrowserRouter as Router,
  useLocation,
} from "react-router-dom";
import "./App.css";
import { Navbar } from "./components/Navbar";
import Home from "./components/pages/home.jsx";
import { Restaurant } from "./components/pages/Restaurants";
import { Offers } from "./components/pages/offers";
import { About } from "./components/pages/about.jsx";
import { Footer } from "./components/Footer.jsx";
import Form from "./components/pages/form.jsx";
import Login from "./components/logreg/login.jsx";
import Register from "./components/logreg/register";
import Cart from "./components/pages/cart";
import { NotFound } from "./components/pages/notfound";
import { Myorders } from "./components/pages/myorders";
import { Profile } from "./components/pages/profile";
import { useEffect } from "react";

function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}
function AppContent() {
  const location = useLocation();
  const definedRoutes = [
    "/",
    "/Restaurants",
    "/offers",
    "/about",
    "/cart",
    "/myorders",
    "/profile",
    "/form/0",
    "/form/1",
    "/form/2",
    "/form/3",
    "/form/4",
    "/form/5",
    "/form/6",
    "/form/7",
  ];
  const shouldHideNavbarAndFooter = !definedRoutes.includes(location.pathname);
  return (
    <>
      {!shouldHideNavbarAndFooter && <Navbar />}
      <div>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/Restaurants" element={<Restaurant />} />
          <Route path="/offers" element={<Offers />} />
          <Route path="/about" element={<About />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/myorders" element={<Myorders />} />
          <Route path="/form" element={<Form />} />
          <Route path="/form/:id" element={<Form />} />
          <Route path="/Profile" element={<Profile />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </div>
      {!shouldHideNavbarAndFooter && <Footer />}
    </>
  );
}
export default App;

import React from "react";
import "./Footer.css";
import { GiFoodTruck } from "react-icons/gi";
import { FaInstagram } from "react-icons/fa6";
import { CiFacebook } from "react-icons/ci";
import { FaTwitter } from "react-icons/fa6";
import { MdMailOutline } from "react-icons/md";
import { IoCallSharp } from "react-icons/io5";
export const Footer = () => {
  return (
    <>
      <section>
        <div className="footer">
          <div className="footerContent">
            <h5>
              <GiFoodTruck className="ficon" /> HungryGo
            </h5>
            <p className="footerp">
              Experience the convenience of having your favorite meals delivered
              straight to your doorstep. With our easy-to-use platform, you can
              browse through a wide selection of cuisines and restaurants Say
              goodbye to hunger and hello to hassle-free dining with HungryGo
              Online Delivery!
            </p>
            <div className="socialIcons">
              <a href="https://www.instagram.com"><FaInstagram className="i1" /></a>
              <a href="https://www.twitter.com"><FaTwitter className="i1" /></a>
              <a href="https://www.facebook.com"><CiFacebook className="i1" /></a>
            </div>
          </div>
          <div className="footerContent">
            <h6>COMPANY</h6>
            <ul>
              <li>
                <a href="/">Home</a>
              </li>
              <li>
                <a href="/restarunts">Restarunts</a>
              </li>
              <li>
                <a href="/gallery">Gallery</a>
              </li>
              <li>
                <a href="/about">About</a>
              </li>
            </ul>
          </div>
          <div className="footerContent">
            <h6 className="heading">FOR QUERIES</h6>
            <ul>
              <li>
                <IoCallSharp /> 050-5646-2721
              </li>
              <li>
                <MdMailOutline /> hungrygo@gmail.com
              </li>
            </ul>
          </div>
        </div>
      </section>
    </>
  );
};

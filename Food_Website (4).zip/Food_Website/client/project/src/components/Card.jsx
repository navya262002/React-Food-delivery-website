import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Card.css";
import data from "./pages/data";
import { IoSearch } from "react-icons/io5";
function Card() {
  const [filter, setFilter] = useState("");
  const [openedImage, setOpenedImage] = useState(null);
  const navigate = useNavigate();
  const searchText = (event) => {
    setFilter(event.target.value);
  };
  let dataSearch = data.container.filter((item) => {
    return Object.keys(item).some(
      (key) =>
        key === "title" &&
        item[key]
          .toString()
          .toLowerCase()
          .includes(filter.toString().toLowerCase())
    );
  });
  const handleMenuClick = (imageUrl) => {
    setOpenedImage(imageUrl);
  };
  const changePage = (index) => {
    navigate(`/form/${index}`);
  };
  const handleCloseModal = () => {
    setOpenedImage(null);
  };
  return (
    <div>
      <div className="header">
        <div className="searchBar">
          <IoSearch className="searchIcon" />
          <input
            className="searchComp"
            type="text"
            onChange={searchText}
            value={filter}
          />
        </div>
      </div>
      <div className="Cards">
        <div className="main">
          {dataSearch.map((item, index) => (
            <div key={item.id} className="container">
              <img src={item.img} alt="img" className="cardimg" />
              <div className="btn">
                <p className="title">{item.title}</p>
                <p className="content">{item.content}</p>
                <button
                  className="btn1"
                  onClick={() => handleMenuClick(item.menuImg)}
                >
                  Menu
                </button>
                <button
                  className="btn1"
                  key={index}
                  onClick={() => changePage(index)}
                >
                  Order Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
      {openedImage && (
        <div className="modal">
          <span className="close" onClick={handleCloseModal}>
            &times;
          </span>
          <img src={openedImage} alt="menu" className="modal-img" />
        </div>
      )}
    </div>
  );
}

export default Card;

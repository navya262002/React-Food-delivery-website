import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";
import "./login.css";
function Login() {
  const navigate = useNavigate();
  const [userName, setUserName] = useState();
  const [password, setPassword] = useState();
 const handleChange = (e) => {
  e.preventDefault();
  axios
    .post("http://127.0.0.1:6008/login", { userName, password })
    .then((result) => {
      console.log(result);
      if (result.data === "Success") {
        navigate("/");
        window.location.reload();
        localStorage.setItem("status", true);
        localStorage.setItem("userName", userName);
      } else if (result.data === "Please register") {
        alert("User not found! Please Register.");
      } else {
        alert("Incorrect Password");
      }
    })
    .catch((err) => console.log(err));
};

  const signup = () => {
    navigate("/register");
  };
  return (
    <div className="loginContainer">
      <div className="formContainer signinBorder">
        <div className="fields">
          <h1 className="loghead">Login</h1>
          <form onSubmit={handleChange} className="inputfileds">
            <input
              type="text"
              placeholder="Username"
              id="userin"
              onChange={(e) => setUserName(e.target.value)}
              required
            />
            <input
              type="password"
              placeholder="Password"
              id="passin"
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <button type="submit" className="loginbtn">
              Login
            </button>
          </form>
          <div id="result"></div>
          <p className="logp">
            Need an account?&nbsp;
            <span onClick={signup} className="signin">
              Register
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}
export default Login;

import { useState } from "react";
import "./register.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";
function SignUp() {
  const navigate = useNavigate();
  const [email, setEmail] = useState();
  const [userName, setUserName] = useState();
  const [password, setPassword] = useState();
  const [confirmPassword, setConfirmPassword] = useState();

  const validatePassword = (password) => {
    const re =
      /^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,}$/;
    return re.test(password);
  };
  const handleChange = (e) => {
    e.preventDefault();
    if (!validatePassword(password)) {
      alert(
        "Password should contain at least one uppercase letter, one special character, and one number(Min 6)."
      );
      return;
    }
    if (password !== confirmPassword) {
      alert("Password and confirm password do not match.");
      return;
    }
    axios
      .post("http://127.0.0.1:6008/register", {
        email,
        userName,
        password,
        confirmPassword,
      })
      .then((res) => {
        console.log(res);
        if (res.data === "Email Already Registered") {
          alert("Email Already Exists");
        } else if (res.data === "Username Already Taken") {
          alert("Username already exists. Please try with another username.");
        } else {
          alert("Registration Successful");
          navigate("/login");
        }
      })
      .catch((err) => console.log(err));
  };

  const login = () => {
    navigate("/login");
  };
  return (
    <div className="regContainer">
      <div className="formContainer signupBorder">
        <div className="fields">
          <h1 className="reghead">Register</h1>
          <form onSubmit={handleChange} className="inputfileds">
            <input
              type="text"
              placeholder="Username"
              id="username"
              onChange={(e) => setUserName(e.target.value)}
              required
            />
            <input
              type="email"
              placeholder="Email"
              id="email"
              required
              onChange={(e) => setEmail(e.target.value)}
            />
            <input
              type="password"
              placeholder="Password"
              id="pass"
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <input
              type="password"
              placeholder="Confirm password"
              id="confirm"
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
            />
            <button type="submit" className="signupbtn">
              Register
            </button>
          </form>
          <div id="result"></div>
          <p className="regp">
            Already have an account?
            <span className="signin" onClick={login}>
              {" "}
              Login
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}
export default SignUp;

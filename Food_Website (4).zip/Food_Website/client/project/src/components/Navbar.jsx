import React, { useState } from "react";
import "./Navbar.css";
import { Link, NavLink } from "react-router-dom";
import { GiFoodTruck } from "react-icons/gi";
import { BsCart } from "react-icons/bs";

export const Navbar = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [first, setFirst] = useState(false);
  const userName = localStorage.getItem("userName");
  const isLoggedIn = localStorage.getItem("status");

  function clear() {
    localStorage.removeItem("status");
    location.reload();
  }

  return (
    <nav>
      <div className="logo">
        <Link to="/" className="title">
          <GiFoodTruck className="icon" /> HungryGo
        </Link>
      </div>
      <div
        className="menu"
        onClick={() => {
          setMenuOpen(!menuOpen);
        }}
      >
        <span></span>
        <span></span>
        <span></span>
      </div>
      <ul
        className={menuOpen ? "open" : " "}
        onClick={() => setMenuOpen(!menuOpen)}
      >
        <li>
          <NavLink to="/">Home</NavLink>
        </li>
        <li>
          <NavLink to="/Restaurants">Restaurants</NavLink>
        </li>
        <li>
          <NavLink to="/offers">Offers</NavLink>
        </li>
        <li>
          <NavLink to="/about">About</NavLink>
        </li>
        <li>
          <NavLink to="/cart">
            <BsCart className="cartIcon" />
          </NavLink>
        </li>
        {isLoggedIn ? (
          <>
           <li className="welcome" onClick={() => setFirst(!first)}>
              <span>Welcome {userName}</span>
            </li>
            <li className="li4">
              <a href="/myorders">
                <span>My Orders</span>
              </a>
            </li>
            <li className="li2">
              <a onClick={clear}>
                <span>Logout</span>
              </a>
            </li>
            {first ? (
              <div className="logoutClass">
                <ul className="userProfile">
                  <li className="li6">
                    <a href="/myorders">
                      <span>My Orders</span>
                    </a>
                  </li>
                  <li className="li6">
                    <a href="/profile">
                      <span>Profile</span>
                    </a>
                  </li>
                  <li className="li7">
                    <a onClick={clear}>
                      <span>Logout</span>
                    </a>
                  </li>
                </ul>
              </div>
            ) : (
              ""
            )}
          </>
        ) : (
          <li>
            <NavLink to="/login" className="logreg">
              Login/Register
            </NavLink>
          </li>
        )}
      </ul>
    </nav>
  );
};

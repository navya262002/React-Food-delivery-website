import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import restaurantData from "./resdata.jsx";
import "./form.css";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Form = () => {
  const { id } = useParams();
  const [restaurant, setRestaurant] = useState(null);
  const userName = localStorage.getItem("userName");
  const [restaurantId, setRestaurantId] = useState([]);
  const [cartItems, setCartItems] = useState([]);
  const [currentRestaurant, setCurrentRestaurant] = useState(null);
  useEffect(() => {
    const selectedRestaurant = restaurantData.dcontainer.find(
      (r) => r.id === parseInt(id)
    );
    setRestaurant(selectedRestaurant);
    localStorage.setItem("restaurants", JSON.stringify(restaurantId));
  }, [id, restaurantId, userName]);

  const addToCart = (item) => {
    const status = localStorage.getItem("status");

    if (!status) {
      toast.warning("Please log in to order", {
        className: "yellow-toast",
      });
    } else {
      const itemExists = cartItems.some((cartItem) => cartItem.id === item.id);

      if (itemExists) {
        toast.error("Item already exists in the cart", {
          className: "red-toast",
        });
      } else {
        setCartItems([...cartItems, item]);
        toast.success("Item added to cart", {
          className: "green-toast",
        });
        setCurrentRestaurant(item.restaurantId);
        setRestaurantId((restaurantId) => [...restaurantId, item]);
        const restaurantName = restaurant.rname;
        localStorage.setItem("currentRestaurantName", restaurantName);
      }
    }
  };
  return (
    <div>
      <ToastContainer />
      {restaurant && (
        <div>
          <div className="menu-container">
            {restaurant.items.map((item, index) => (
              <div key={index} className="menuCard">
                <img src={item.img} alt={item.name} className="menuCard-img" />
                <p>{item.name}</p>
                <p>Rs. {item.price}</p>
                <button onClick={() => addToCart(item)} className="cartbtn">
                  Add to Cart
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
export default Form;

import React, { useState } from "react";
import { useEffect } from "react";
import axios from "axios";
import nouser from "../../assets/nouser.jpg";
import { Link } from "react-router-dom";
import "./profile.css";
export const Profile = () => {
  const [email, setEmail] = useState();
  const [userimage, setUserImage] = useState(null);
  const userName = localStorage.getItem("userName");
  const address = localStorage.getItem(`${userName}deliveryAddress`);
  const status = localStorage.getItem("status")
  useEffect(() => {
    axios
      .post("http://127.0.0.1:6008/profile", { userName })
      .then((res) => {
        setEmail(res.data.email);
        console.log(res);
      })
      .catch((err) => console.log(err));
  }, [userName]);
  if(status==="true"){
  return (
    <div className="profile">
      <div className="pImg">
        {userimage ? (
          <img
            className="userimg"
            src={URL.createObjectURL(userimage)}
            alt="userimage"
          />
        ) : (
          <img className="userimg" src={nouser} alt="nouser" />
        )}
      </div>
      <input
        type="file"
        onChange={(e) => setUserImage(e.target.files[0])}
        className="file"
      />
      <p>UserName: {userName}</p>
      <p>Email: {email}</p>
      <p>Address: {address}</p>
      <p>
        Click here to show Orders{" "}
        <Link to="/myorders">
          <button className="pbtn">My Orders</button>
        </Link>
      </p>
    </div>
  );
  }
  else{

  }
};


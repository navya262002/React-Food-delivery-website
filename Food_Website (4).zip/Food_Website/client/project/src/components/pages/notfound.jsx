import React from 'react'
import "./notfound.css"
export const NotFound = () => {
  return (
    <div className='notfound'>
        <h1>Error 404
          Page not found!
        </h1>
    </div>
  )
}

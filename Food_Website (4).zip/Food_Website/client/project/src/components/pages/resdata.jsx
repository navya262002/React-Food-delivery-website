import res1m1 from "../../assets/res1m1.jpg"
import res1m2 from "../../assets/res1m2.jpg"
import res1m3 from "../../assets/res1m3.jpg"
import res1m4 from "../../assets/res1m4.jpg"
import res1m5 from "../../assets/res1m5.jpg"
import res1m6 from "../../assets/res1m6.jpg"
import res1m7 from "../../assets/res1m7.jpg"
import res1m8 from "../../assets/res1m8.jpg"
import res1m9 from "../../assets/res1m9.jpg"
import res1m10 from "../../assets/res1m10.jpg"
import res1m11 from "../../assets/res1m11.jpg"
import res1m12 from "../../assets/res1m12.jpg"

import res2m1 from "../../assets/res2m1.jpg"
import res2m2 from "../../assets/res2m2.jpg"
import res2m3 from "../../assets/res2m3.jpg"
import res2m4 from "../../assets/res2m4.jpg"
import res2m5 from "../../assets/res2m5.jpg"
import res2m6 from "../../assets/res2m6.jpg"
import res2m7 from "../../assets/res2m7.jpg"
import res2m8 from "../../assets/res2m8.jpg"

import res3m1 from "../../assets/res3m1.jpg"
import res3m2 from "../../assets/res3m2.jpg"
import res3m3 from "../../assets/res3m3.jpg"
import res3m4 from "../../assets/res3m4.jpg"
import res3m5 from "../../assets/res3m5.jpg"
import res3m6 from "../../assets/res3m6.jpg"
import res3m7 from "../../assets/res3m7.jpg"
import res3m8 from "../../assets/res3m8.jpg"

import res4m1 from "../../assets/res4m1.jpg"
import res4m2 from "../../assets/res4m2.jpg"
import res4m3 from "../../assets/res4m3.jpg"
import res4m4 from "../../assets/res4m4.jpg"
import res4m5 from "../../assets/res4m5.jpg"
import res4m6 from "../../assets/res4m6.jpg"
import res4m7 from "../../assets/res4m7.jpg"
import res4m8 from "../../assets/res4m8.jpg"

import res5m1 from "../../assets/res5m1.jpg"
import res5m2 from "../../assets/res5m2.jpg"
import res5m3 from "../../assets/res5m3.jpg"
import res5m4 from "../../assets/res5m4.jpg"
import res5m5 from "../../assets/res5m5.jpg"
import res5m6 from "../../assets/res5m6.jpg"
import res5m7 from "../../assets/res5m7.jpg"
import res5m8 from "../../assets/res5m8.jpg"

import res6m1 from "../../assets/res6m1.jpg"
import res6m2 from "../../assets/res6m2.jpg"
import res6m3 from "../../assets/res6m3.jpg"
import res6m4 from "../../assets/res6m4.jpg"
import res6m5 from "../../assets/res6m5.jpg"
import res6m6 from "../../assets/res6m6.jpg"
import res6m7 from "../../assets/res6m7.jpg"
import res6m8 from "../../assets/res6m8.jpg"

import res7m1 from "../../assets/res7m1.jpg"
import res7m2 from "../../assets/res7m2.jpg"
import res7m3 from "../../assets/res7m3.jpg"
import res7m4 from "../../assets/res7m4.jpg"
import res7m5 from "../../assets/res7m5.jpg"
import res7m6 from "../../assets/res7m6.jpg"
import res7m7 from "../../assets/res7m7.jpg"
import res7m8 from "../../assets/res7m8.jpg"

import res8m1 from "../../assets/res8m1.jpg"
import res8m2 from "../../assets/res8m2.jpg"
import res8m3 from "../../assets/res8m3.jpg"
import res8m4 from "../../assets/res8m4.jpg"
import res8m5 from "../../assets/res8m5.jpg"
import res8m6 from "../../assets/res8m6.jpg"
import res8m7 from "../../assets/res8m7.jpg"
import res8m8 from "../../assets/res8m8.jpg"

const restaurantData = {
  dcontainer: [
    {
      id:0,
      rname:"Indian Restaurant",
      items: [
        { id:0,name: "South Indian Thali", price: 260 , img:res1m1},
        { id:1,name: "North Indian Thali", price: 260,img:res1m2 },
        { id:2,name: "Veg Biryani", price: 150,img:res1m3 },
        { id:3,name: "Veg Fried Rice", price: 99,img:res1m4 },
        { id:4,name: "Paneer Fried Rice", price: 130 ,img:res1m5},
        { id:5,name: "Gobi Fried Rice", price: 100 ,img:res1m6},
        { id:6,name: "Gobi Manchurian", price: 60 ,img:res1m7},
        { id:7,name: "Mushroom Manchurian", price: 65 ,img:res1m8},
        { id:8,name: "Paneer Pepper Dry", price: 90 ,img:res1m9},
        { id:9,name: "Aloo 65", price: 65 ,img:res1m10},
        { id:10,name: "Mushroom Chilli", price: 90 ,img:res1m11},
        { id:11,name: "Baby Corn Manchurian", price: 100 ,img:res1m12}
      ]
    },
    {
      id:1,
      rname:"Biryani Paradise",
      items: [
        {id:0, name: "Chicken 65", price: 100 ,img:res2m1},
        {id:1, name: "Mutton Fry", price: 120 ,img:res2m2},
        {id:2, name: "Chicken Lollipop", price: 135 ,img:res2m3 },
        {id:3, name: "Prawns Fry", price: 160 ,img:res2m4},
        {id:4, name: "Chilli Chicken", price: 130 ,img:res2m5},
        {id:5, name: "Chicken Biryani", price: 160 ,img:res2m6},
        {id:6, name: "Mutton Biryani", price: 250 ,img:res2m7},
        {id:7, name: "Boneless Chicken Biryani", price: 180 ,img:res2m8}
      ]
    },
    {
      id:2,
      rname:"Desert Delight",
      items: [
        {id:0, name: "Cheese Cake", price: 190 ,img:res3m1},
        {id:1, name: "Muffin", price: 99 ,img:res3m2},
        {id:2, name: "Pancake", price: 150 ,img:res3m3},
        {id:3, name: "Waffle", price: 120 ,img:res3m4 },
        {id:4, name: "Brownie", price: 99 ,img:res3m5},
        {id:5, name: "Tiramisu", price: 190 ,img:res3m6},
        {id:6, name: "Donout", price: 99 ,img:res3m7},
        {id:7, name: "Choco Lava Cake", price: 99 ,img:res3m8},
       
      ]
    },
    {
      id:3,
      rname:"Dosa Delight",
      items: [
        {id:0, name: "Idly", price: 30 ,img:res4m1},
        {id:1, name: "Dosa", price: 60 ,img:res4m2},
        {id:2, name: "Poori", price: 50 ,img:res4m3},
        {id:3, name: "Pongal", price: 50 ,img:res4m4 },
        {id:4, name: "Vada", price: 40 ,img:res4m5},
        {id:5, name: "Idly & Vada", price: 60 ,img:res4m6},
        {id:6, name: "Karam Dosa", price: 80 ,img:res4m7},
        {id:7, name: "Masala Dosa", price: 90 ,img:res4m8},
       
      ]
    },
    {
      id:4,
      rname:"Juicy Heaven Cafe",
      items: [
        {id:0, name: "Watermelon", price: 40 ,img:res5m1},
        {id:1, name: "Mango", price: 80 ,img:res5m7},
        {id:2, name: "Orange", price: 50 ,img:res5m3},
        {id:3, name: "Pineapple", price: 50 ,img:res5m8},
        {id:4, name: "Strawberry", price: 80 ,img:res5m4 },
        {id:5, name: "Pomegranate", price: 60 ,img:res5m5},
        {id:6, name: "Papaya", price: 60 ,img:res5m6}, 
        {id:7, name: "Grapes", price: 60 ,img:res5m2},
      ]
    },
    {
      id:5,
      rname:"Sweet Tooth",
      items: [
        { id:0,name: "Gulab Jamun(4pc)", price: 65 ,img:res6m1},
        { id:1,name: "Rasgulla(3pc", price: 70,img:res6m2},
        { id:2,name: "Rasmalai(3pc)", price: 70 ,img:res6m3},
        { id:3,name: "Jalebi(4pc)", price: 50,img:res6m4 },
        { id:4,name: "Soan Papdi(3pc)", price: 40 ,img:res6m5},
        { id:5,name: "Kheer", price: 70 ,img:res6m6},
        { id:6,name: "Halwa", price: 70 ,img:res6m7},
        { id:7,name: "Kulfi", price: 30 ,img:res6m8},
       
      ]
    },
    {
      id:6,
      rname:"The Cupcake",
      items: [
        {id:0, name: "Red Velvet", price: 120 ,img:res7m1},
        {id:1, name: "Lemon Cake", price: 60 ,img:res7m2},
        {id:2, name: "Chocolate Fudge", price: 120 ,img:res7m7},
        {id:3, name: "Coconut Lime", price: 65 ,img:res7m3},
        {id:4, name: "Coffee Toffee", price: 130 ,img:res7m4 },
        {id:5, name: "Almond Raspberry", price: 180,img:res7m5},
        {id:6, name: "Vegan Chocolate", price: 150 ,img:res7m6},
        {id:7, name: "Classic Vanilla", price: 100 ,img:res7m8},
       
      ]
    },
    {
      id:7,
      rname:"Coffee Brew",
      items: [
        {id:0, name: "Caramel Coffee", price: 80 ,img:res8m1},
        {id:1, name: "Caro Mocha", price: 110 ,img:res8m2},
        {id:2, name: "Espresso", price: 100 ,img:res8m3},
        {id:3, name: "Cramel Late", price: 120 ,img:res8m4 },
        {id:4, name: "Green Tea", price: 50 ,img:res8m5},
        {id:5, name: "Ginger Tea", price: 40 ,img:res8m6},
        {id:6, name: "Coffee Jelly", price: 100 ,img:res8m7},
        {id:7, name: "Lemon Tea", price: 30 ,img:res8m8},
       
      ]
    },
  ]
 };
 export default restaurantData;


import React from "react";
import Card from "../Card.jsx";
import "./restaurant.css";

export const Restaurant = () => {
  return (
    <>
      <div className="cards">
        <Card />
      </div>
    </>
  );
};

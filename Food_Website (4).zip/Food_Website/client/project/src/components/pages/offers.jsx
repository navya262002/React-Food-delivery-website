import React from "react";
import "./offers.css";
import { MdDeliveryDining } from "react-icons/md";
import { Link } from "react-router-dom";
import offimg2 from "../../assets/offimg2.jpg";
import offimg3 from "../../assets/offimg3.jpg";
import offimg4 from "../../assets/offimg4.jpg";
import offimg5 from "../../assets/offimg5.jpg";
import offimg6 from "../../assets/offimg6.jpg";
export const Offers = () => {
  return (
    <>
      <div className="offers">
        <marquee scrollamount="7" behavior="scroll" direction="left" loop>
          <p>
            Free Delivery on orders above 300{" "}
            <MdDeliveryDining className="picon" />
            <Link to="/Restarunts" className="link">
              Click here..
            </Link>
          </p>
        </marquee>
      </div>
      <p className="head">Deals and Combos</p>
      <div className="offimages">
        <img src={offimg2} className="offimg" />
        <img src={offimg3} className="offimg" />
      </div>
      <p className="gcards">Gift Cards</p>
      <div className="giftcards">
        <img src={offimg4} className="giftcards" />
        <img src={offimg5} className="giftcards" />
        <img src={offimg6} className="giftcards" />
      </div>
    </>
  );
};

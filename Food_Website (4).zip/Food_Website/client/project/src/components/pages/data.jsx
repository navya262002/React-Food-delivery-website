import resimg1 from "../../assets/resimg1.jpg";
import resimg2 from "../../assets/resimg2.jpg";
import resimg3 from "../../assets/resimg3.jpg";
import resimg4 from "../../assets/resimg4.jpg";
import resimg5 from "../../assets/resimg5.jpg";
import resimg6 from "../../assets/resimg6.jpg";
import resimg7 from "../../assets/resimg7.jpg";
import resimg8 from "../../assets/resimg8.jpg";
import menu1 from "../../assets/menu1.jpg";
import menu2 from "../../assets/menu2.jpg";
import menu3 from "../../assets/menu3.jpg";
import menu4 from "../../assets/menu4.jpg";
import menu5 from "../../assets/menu5.jpg";
import menu6 from "../../assets/menu6.jpg";
import menu7 from "../../assets/menu7.jpg";
import menu8 from "../../assets/menu8.jpg";
const data = {
  container: [
    {
      id: 1,
      img: resimg1,
      menuImg: menu1,
      title: "Indian Restaurant",
      content: "Where every dish is a masterpiece",
    },
    {
      id: 2,
      img: resimg2,
      menuImg: menu2,
      title: "Biryani Paradise",
      content: "Where passion meets spice",
    },
    {
      id: 3,
      img: resimg3,
      menuImg: menu3,
      title: "Desert Delights",
      content: "Your destination for delicious",
    },
    {
      id: 4,
      img: resimg4,
      menuImg: menu4,
      title: "Dosa Delight",
      content: "Serving happiness on a plate",
    },
    {
      id: 5,
      img: resimg5,
      menuImg: menu5,
      title: "Juicy Heaven Cafe",
      content: "Taste the vitality in every drop",
    },
    {
      id: 6,
      img: resimg6,
      menuImg: menu6,
      title: "Sweet Tooth",
      content: "Divine Delights",
    },
    {
      id: 7,
      img: resimg7,
      menuImg: menu7,
      title: "The Cupcake",
      content: "Where every dish is a masterpiece",
    },
    {
      id: 8,
      img: resimg8,
      menuImg: menu8,
      title: "Coffee Brew",
      content: "Where every dish is a masterpiece",
    },
  ],
};
export default data;

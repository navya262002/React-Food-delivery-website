import React from "react";
import "./about.css";
import aboutimg1 from "../../assets/aboutimg1.jpg";
import aboutimg2 from "../../assets/aboutimg2.jpg";
import aboutimg3 from "../../assets/aboutimg3.jpg";
import aboutimg4 from "../../assets/aboutimg4.jpg";
export const About = () => {
  return (
    <>
      <div className="acontent">
        <img src={aboutimg1} alt="image" className="aimg" />
        <div className="text">
          <h1>We believe in quality and fast delivery</h1>
          <p>
            Where culinary delights meet doorstep convenience. Our passion for
            good food and seamless service drives us to connect you with a world
            of flavors, right at your fingertips.
          </p>
        </div>
      </div>
      <div className="boxes">
        <div className="box1">
          <img src={aboutimg2} alt="food" />
          <div className="bcontent">
            <p>
              Discover amazing food from different parts of the world! Whether
              you're in the mood for spicy Thai dishes, comforting Italian
              pasta, or flavorful Mexican street food, we've got something
              delicious for everyone. Our chefs use the best ingredients to
              create tasty meals that you can enjoy at home. Order now and
              experience a world of flavors delivered to your doorstep We source
              the finest ingredients, ensuring that each dish is prepared with
              attention to detail. From the freshest produce to the highest
              quality,we spare no effort in delivering a dining experience that
              exceeds your expectations.
            </p>
          </div>
        </div>
        <div className="box2">
          <img src={aboutimg3} alt="image" />
          <div className="bcontent">
            <p>
              With our commitment to efficiency and speed, you can count on us
              to deliver your order promptly, so you can enjoy your meal without
              the wait. Our streamlined delivery process ensures that your food
              is prepared promptly and dispatched without delay. From the moment
              you place your order to the moment it arrives at your doorstep,
              we're working tirelessly to make sure your meal is delivered as
              quickly as possible. But don't worry we never sacrifice quality
              for speed.Our mission is to make every meal memorable by
              delivering exceptional food experiences to your doorstep.
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

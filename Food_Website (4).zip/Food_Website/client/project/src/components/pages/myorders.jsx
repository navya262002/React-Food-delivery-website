import React, { useState, useEffect } from "react";
import axios from "axios";
import "./myorders.css";

export const Myorders = () => {
  const [orders, setOrders] = useState([]);
  const [orderId, setOrderId] = useState("");
  const status = localStorage.getItem("status");
  const userName = localStorage.getItem("userName");

  useEffect(() => {
    axios
      .post("http://127.0.0.1:6008/orders/request", { userName })
      .then((res) => {
        setOrders(res.data);
      })
      .catch((err) => console.log(err));
  }, [userName]);

  return (
    <div>
      {status ? (
        orders.length > 0 ? (
          <table className="responsive-table">
            <thead>
              <tr>
                <th className="order-id">Order ID</th>
                <th className="restaurant">Restaurant</th>
                <th className="items">Items</th>
                <th className="delivery-charges">Delivery Charges</th>
                <th className="final-cost">Final Cost</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order) => (
                <tr key={order.id} className="order-row">
                  <td>{order.orderId}</td>
                  <td>{order.resname}</td>
                  <td className="item-list">
                    <ul>
                      {order.items.map((item, index) => (
                        <li key={index} className="item">
                          <p>
                            {item.name} x {item.quantity}
                          </p>
                          <p>{item.price}</p>
                        </li>
                      ))}
                    </ul>
                  </td>
                  <td>{order.deliveryCharge}</td>
                  <td>{order.finalCost}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>You have not ordered anything yet.</p>
        )
      ) : (
        <p>Login to view your orders</p>
      )}
    </div>
  );
};

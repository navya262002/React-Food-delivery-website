import React, { useState } from "react";
import axios from "axios";
import "./cart.css";
import emptycart from "../../assets/emptycart.jpg";
import { RiDeleteBin6Line } from "react-icons/ri";
import { FaMinus } from "react-icons/fa6";
import { FaPlus } from "react-icons/fa6";
import { useEffect } from "react";
const Cart = () => {
  const userName = localStorage.getItem("userName");
  const status = localStorage.getItem("status");
  const [giftCardPrice, setGiftCardPrice] = useState(0);
  let initialRestaurant = JSON.parse(localStorage.getItem("restaurants"));
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [quantity, setQuantity] = useState(initialRestaurant.map(() => 1));
  const [restaurant, setRestaurant] = useState(initialRestaurant);
  const resname = localStorage.getItem("currentRestaurantName");
  const [isDeleting, setIsDeleting] = useState(null);
  const handleGiftCardChange = (event) => {
    const selectedGiftCard = event.target.value;
    if (selectedGiftCard === "Select...") {
      setGiftCardPrice(0);
    } else {
      setGiftCardPrice(50);
    }
  };
  const increaseQuantity = (index) => {
    const newQuantity = [...quantity];
    newQuantity[index]++;
    setQuantity(newQuantity);
  };
  const decreaseQuantity = (index) => {
    const newQuantity = [...quantity];
    if (newQuantity[index] > 1) {
      newQuantity[index]--;
      setQuantity(newQuantity);
    }
  };
  const deleteItem = (index) => {
    setIsDeleting(index);
    setTimeout(() => {
      const newRestaurant = [...restaurant];
      newRestaurant.splice(index, 1);
      setRestaurant(newRestaurant);
      localStorage.setItem("restaurants", JSON.stringify(newRestaurant));
      setIsDeleting(null);
    }, 1000);
  };
  useEffect(() => {
    const savedAddress = localStorage.getItem(`${userName}deliveryAddress`);
    if (savedAddress) {
      setDeliveryAddress(savedAddress);
    }
  }, []);  
  const handleCheckout = async () => {
    try {
      const generateOrderId = () => {
        return Math.floor(Math.random() * 9000) + 1000;
      };
      const order = {
        userName,
        resname,
        items: restaurant.map((item, index) => ({
          name: item.name,
          quantity: quantity[index],
          price: item.price,
        })),
        totalCost,
        finalCost,
        deliveryCharge,
        deliveryAddress,
        orderId: generateOrderId(),
      };
      const response = await axios.post("http://127.0.0.1:6008/orders", order);
      const { orderId } = response.data;
      console.log(`Order placed! Order ID: ${orderId}`);
      localStorage.setItem(`${userName}deliveryAddress`, deliveryAddress);
      console.log(resname);
      alert("Your Order has been placed sucessfully");
      window.location.href = "/myorders";
    } catch (error) {
      console.error("Error placing order:", error.message);
    }
  };
  const totalCost = restaurant.reduce(
    (total, item, index) => total + item.price * quantity[index],
    0
  );
  const deliveryCharge = totalCost > 300 ? 0 : 50;
  const finalCost = totalCost + deliveryCharge + giftCardPrice;
  if (status === "true" && restaurant.length > 0) {
    return (
      <>
        <div className="cartcontent">
          <table className="cart-table">
            <thead className="cart-thead">
              <tr className="cart-row">
                <th className="cart-th">Item</th>
                <th className="cart-th">Price</th>
                <th className="cart-th">Quantity</th>
                <th className="cart-th">Remove</th>
              </tr>
            </thead>
            <tbody className="cart-tbody">
              {restaurant.map((items, index) => (
                <tr key={index} className="cart-row">
                  <td className="cart-td">
                    <img src={items.img} alt="image" className="cartitemimg" />
                    &nbsp;{items.name}
                  </td>
                  <td className="cart-td">Rs. {items.price}</td>
                  <td className="cart-td">
                    <button
                      onClick={() => decreaseQuantity(index)}
                      className="cbtn"
                    >
                      <FaMinus className="minus" />
                    </button>
                    <span> {quantity[index]} </span>
                    <button
                      onClick={() => increaseQuantity(index)}
                      className="cbtn"
                    >
                      <FaPlus className="plus" />
                    </button>
                  </td>
                  <td className="cart-td">
                    <button onClick={() => deleteItem(index)} className="rbtn">
                      <RiDeleteBin6Line className="remove" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="checkout-container">
          <h4>Checkout Details</h4>
          <div className="checkout-column">
            <label>Add Cooking Instructions(Optional)</label>
            <br />
            <textarea cols="32" rows="4"></textarea>
            <br />
            <label>Gift Cards</label>
            <br />
            <select onChange={handleGiftCardChange}>
              <option>Select...</option>
              <option>Birthday - Rs.50</option>
              <option>Best Wishes - Rs.50</option>
              <option>Congratulations - Rs.50</option>
            </select>
          </div>
          <div className="checkout-column">
            <label>Address*</label>
            <br />
            <textarea
              cols="40"
              rows="4"
              value={deliveryAddress}
              onChange={(e) => setDeliveryAddress(e.target.value)}
              placeholder="123-StreetName-City-Pincode"
              required
            ></textarea>
            <div className="pricedetails">
              <p>Total Cost: {totalCost}</p>
              <p>Delivery Charge: {deliveryCharge}</p>
              <p>Gift Card: {giftCardPrice}</p>
              <p>Final Cost: {finalCost}</p>
            </div>
          </div>
          <div className="checkoutbtn">
            <input type="checkbox" required className="cod" />{" "}
            <label className="cod">Cash on Delivery</label>
            <br />
            <button onClick={handleCheckout} className="checkout-center">
              Checkout
            </button>
          </div>
        </div>
      </>
    );
  } else {
    return (
      <div className="emptycartcontainer">
        <img src={emptycart} alt="empty cart" className="emptycart" />
        <div className="emptycarttext">
          <h1>Your cart is empty!</h1>
        </div>
      </div>
    );
  }
};
export default Cart;

import Carousel from "react-bootstrap/Carousel";
import himg1 from "../../assets/himg1.jpg";
import himg2 from "../../assets/himg2.jpg";
import himg3 from "../../assets/himg3.jpg";
import "bootstrap/dist/css/bootstrap.min.css";
import "./home.css";
import data from "../pages/data.jsx";
import { useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
function Home() {
  const navigate = useNavigate();
  const changePage = (index) => {
    navigate(`/form/${index}`);
  };
  const handleMenuClick = (imageUrl) => {
    setOpenedImage(imageUrl);
  };
  const handleCloseModal = () => {
    setOpenedImage(null);
  };

  const [openedImage, setOpenedImage] = useState(null);
  return (
    <>
      <div className="homeContainer">
        <Carousel>
          <Carousel.Item interval={900}>
            <img className="d-block w-100" src={himg1} alt="First slide" />
            <Carousel.Caption>
              <h2 className="ctext">Crave-worthy cuisine, just a click away</h2>
            </Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item interval={900}>
            <img className="d-block w-100" src={himg2} alt="Second slide" />
          </Carousel.Item>
          <Carousel.Item interval={900}>
            <img className="d-block w-100" src={himg3} alt="Third slide" />
          </Carousel.Item>
        </Carousel>
      </div>
      <div className="htext">
        <h5>Recommended Restaurants</h5>
      </div>
      <div className="main1">
        {data.container.map((item, index) => {
          if (index < 4) {
            return (
              <div key={item.id} className="container">
                <img src={item.img} alt="img" className="cardimg" />
                <div className="btn">
                  <p className="title">{item.title}</p>
                  <p className="content">{item.content}</p>
                  <button
                    className="btn1"
                    onClick={() => handleMenuClick(item.menuImg)}
                  >
                    Menu
                  </button>
                  <button
                    className="btn1"
                    key={index}
                    onClick={() => changePage(index)}
                  >
                    Order Now
                  </button>
                </div>
              </div>
            );
          }
        })}
      </div>
      <div className="explore">
        <Link to="/Restaurants">
          <button className="hbtn">Explore Now</button>
        </Link>
      </div>
      {openedImage && (
        <div className="modal">
          <span className="close" onClick={handleCloseModal}>
            &times;
          </span>
          <img src={openedImage} alt="menu" className="modal-img" />
        </div>
      )}
    </>
  );
}
export default Home;

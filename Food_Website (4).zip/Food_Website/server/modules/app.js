const mongoose = require("mongoose");
const cors = require("cors");
const userdetails = require("./mongo.js");
const express = require('express');
const Order = require("./cartSchema.js");
const app = express();
app.use(express.json());
app.use(cors());
mongoose.connect("mongodb://127.0.0.1:27017/users").then(()=>{
         console.log("mongodb connected");
     }).catch(()=>{
            console.log("mongodb not connected");
         })
         app.post("/register", (req, res) => {
            const { email, userName } = req.body;
            userdetails.findOne({ email: email })
              .then(user => {
                if (user) {
                  res.json("Email Already Registered");
                } else {
                  userdetails.findOne({ userName: userName })
                    .then(user => {
                      if (user) {
                        res.json("Username Already Taken");
                      } else {
                        userdetails.create(req.body)
                          .then(details => res.json(details))
                          .catch(err => res.json(err));
                      }
                    });
                }
              })
              .catch(err => res.json(err));
          });
          
          app.post("/login", (req,res)=>{
            const {userName, password} = req.body;
            userdetails.findOne({userName: userName})
            .then(user => {
                if(user){
                    if(user.password === password){
                        res.json("Success");
                    }
                    else{
                        res.json("Password Incorrect");
                    }
                }else{
                    res.json("Please register");
                }
            }).catch(err=>res.json(err))
        })
app.post('/orders', async (req, res) => {
    try {
      const { userName, items, totalCost, finalCost,deliveryCharge, deliveryAddress,orderId,resname} = req.body;
      const order = new Order({
        orderId,
        userName,
        items,
        totalCost,
        resname,
        deliveryCharge,
        finalCost,
        deliveryAddress,
      });
      await order.save();
      res.json({ message: 'Order created successfully' });
    } catch (error) {
      console.error('Error creating order:', error);
      res.status(500).json({ error: 'Error creating order' });
    }
  });
  app.post("/orders/request", (req, res) => {
    const { userName } = req.body;
    if (!userName) {

        return res.status(400).json({ error: "Missing required parameter: userName" });
    }
    Order.find({ userName })
        .then(orders => {
            if (!orders || orders.length === 0) {
                return res.status(404).json({ error: "No orders found for the specified user." });
            }
            res.json(orders);
        })
        .catch(err => res.status(500).json({ error: "An error occurred while fetching orders." }));
});
app.post("/profile", (req,res) =>{
    const {userName}=req.body;
    if (!userName) {
        return res.status(400).json({ error: "Missing required parameter: userName" });
    }
    userdetails.findOne({ userName })
        .then(details => {
            if (!details || details.length === 0) {
                return res.status(404).json({ error: "No orders found for the specified user." });
            }
            res.json(details);
        })
        .catch(err => res.status(500).json({ error: "An error occurred while fetching orders." }));
});
app.listen(6008, ()=>{
    console.log("server is running");
})
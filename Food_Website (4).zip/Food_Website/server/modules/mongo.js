const mongoose = require("mongoose");
const registerSchema = new mongoose.Schema({
    email : String,
    userName : String,
    password : String,
    confirmPassword : String,
});
 
const userdetails = mongoose.model("userdetails", registerSchema);
 
module.exports = userdetails;
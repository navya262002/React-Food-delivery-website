const mongoose = require("mongoose");
const cartSchema = new mongoose.Schema({
  orderId: Number,
  userName: String,
  items: [
      {
          name: { type: String, required: true },
          quantity: { type: Number, required: true },
          price:{ type: Number, required: true },
      },
  ],
  totalCost: { type: Number, required: true },
  deliveryCharge: {type: Number,required:true},
  finalCost: { type:Number , required: true},
  deliveryAddress: { type: String, required: true },
  resname: {type: String, required:true},
});
const Order = mongoose.model('Order', cartSchema);
 
module.exports = Order;
